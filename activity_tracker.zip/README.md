~~Activity~~ Chikin Tracker
================

This is an ~~activity~~ chikin tracker extension for Chromium. It logs Web usage for time concious people and can be used for analysing amount of time spend on different websites.

*NOTE* This extension just works and lacks a lot of functionality and UI, as it is still under (slow?) development. Contributions are more than welcome!

CHANGELOG
---------

**Version 1.2**
Added mor chikin

**Version 1.1**  
Fixed some bugs:   

* Duplicated time logging for multiple windows  
* Stopped time logging when window out of focus.  

**Version 1.0**  
Basic functionality added
